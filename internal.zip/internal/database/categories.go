// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
package database

import (
	"fmt"
)

type Category struct {
	ID          string `db:"id" json:"id"`
	Name        string `db:"category_name" json:"name"`
	BoxartURL   string `json:"box_art_url"`
	ViewerCount int    `db:"vc" json:"-"`
	IGDB        string `db:"igdb_id" json:"igdb_id"`
}

func (q *Query) GetCategories(cat Category) (*DBResponse, error) {
	var r []Category
	rows, err := q.DB.NamedQuery(generateSQL("select * from categories", cat, SEP_AND)+q.SQL, cat)
	if err != nil {
		return nil, err
	}

	for rows.Next() {
		var cat Category
		err := rows.StructScan(&cat)
		if err != nil {
			return nil, err
		}
		r = append(r, cat)
	}

	dbr := DBResponse{
		Data:  r,
		Limit: q.Limit,
		Total: len(r),
	}

	if len(r) != q.Limit {
		q.PaginationCursor = ""
	}

	dbr.Cursor = q.PaginationCursor

	return &dbr, err
}

func (q *Query) InsertCategory(category Category, upsert bool) error {
	_, err := q.DB.NamedExec(`insert into categories values(:id, :category_name, :igdb_id)`, category)
	return err
}

func (q *Query) SearchCategories(query string) (*DBResponse, error) {
	r := []Category{}
	err := q.DB.Select(&r, `select * from categories where lower(category_name) like lower($1) `+q.SQL, fmt.Sprintf("%%%v%%", query))
	if err != nil {
		return nil, err
	}
	dbr := DBResponse{
		Data:  r,
		Limit: q.Limit,
		Total: len(r),
	}

	if len(r) != q.Limit {
		q.PaginationCursor = ""
	}

	dbr.Cursor = q.PaginationCursor

	return &dbr, err
}

func (q *Query) GetTopGames() (*DBResponse, error) {
	r := []Category{}

	err := q.DB.Select(&r, "select c.id, c.category_name, c.igdb_id, IFNULL(SUM(s.viewer_count),0) as vc from categories c left join users u on c.id = u.category_id left join streams s on s.broadcaster_id = u.id  group by c.id, c.category_name order by vc desc"+q.SQL)
	if err != nil {
		return nil, err
	}

	dbr := DBResponse{
		Data:  r,
		Limit: q.Limit,
		Total: len(r),
	}

	if len(r) != q.Limit {
		q.PaginationCursor = ""
	}

	dbr.Cursor = q.PaginationCursor

	return &dbr, err
}
