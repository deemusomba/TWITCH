// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0
package clips

import "github.com/twitchdev/twitch-cli/internal/database"

var db database.CLIDatabase
